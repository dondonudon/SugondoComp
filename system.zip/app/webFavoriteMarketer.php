<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class webFavoriteMarketer extends Model
{
    protected $table = 'web_favorite_marketer';
    protected $fillable = ['id_marketer'];
}
