<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class webTopMarketer extends Model
{
    protected $table = 'web_top_marketer';
    protected $fillable = ['id_marketer'];
}
