<footer class="main-footer">
    <!-- To the right -->
{{--    <div class="float-right d-none d-sm-inline">--}}
{{--        Developed by <a href="{{ config('app.company_web') }}">{{ config('app.company_name') }}</a>--}}
{{--    </div>--}}
    <!-- Default to the left -->
    <strong><i class="far fa-copyright"></i> {{ date('Y') }} <a href="{{ config('app.client_web') }}">{{ config('app.app_client_name') }}</a></strong>
</footer>
