<section class="ftco-section goto-here" id="sectionForSale">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 heading-section text-center ftco-animate mb-5">
                <span class="subheading">What we offer</span>
                <h2 class="mb-2">Exclusive Offer For You</h2>
            </div>
        </div>
        <div class="row">
            <?php $__currentLoopData = $info['rumah-dijual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-4 mb-4">
                <div class="card">
                    <img src="<?php echo e(url('storage/'.$i->gambar)); ?>" class="card-img-top" alt="<?php echo e($i->nama_rumah); ?>" style="height: 15rem; width: auto;">
                    <ul class="list-group list-group-flush">
                        <li class="list-group-item">
                            <div class="row">
                                <div class="col text-truncate">
                                    <strong><?php echo e($i->nama_rumah); ?></strong>
                                </div>
                            </div>
                        </li>
                        <li class="list-group-item" style="background-color: yellow">
                            <strong class="text-gray-dark">Rp <?php echo e(number_format($i->harga,2)); ?></strong>
                        </li>
                    </ul>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-tiles"></i> LT <?php echo e($i->luas_tanah); ?> || LB <?php echo e($i->luas_bangunan); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-stairs"></i> <?php echo e($i->lantai); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-hotel"></i> <?php echo e($i->kamar_tidur); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-bathtub-with-opened-shower"></i> <?php echo e($i->kamar_mandi); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-kitchen"></i> <?php echo e($i->dapur_bersih); ?>

                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-kitchen"></i> <?php echo e($i->dapur_kotor); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-herbal-spa-treatment-leaves"></i> <?php echo e($i->taman); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-compass-with-white-needles"></i> <?php echo e($i->arah_rumah); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-lightning-in-a-circle"></i> <?php echo e($i->listrik); ?>

                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col text-truncate">
                                        <i class="flaticon-family-sofa"></i> <?php echo e($i->furniture); ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="card-footer">
                        <a href="<?php echo e(url('rumah-dijual/detail/'.$i->id)); ?>" class="btn btn-primary btn-block">
                            <span class="text-dark">Detail</span>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</section>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/rumah-dijual.blade.php ENDPATH**/ ?>