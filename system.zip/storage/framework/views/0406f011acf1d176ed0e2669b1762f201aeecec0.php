<?php $__env->startSection('page title','WEB Component Header Section'); ?>

<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg">

                    <div class="card card-primary card-outline">

                        <form id="formData">
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-lg">
                                        <div class="form-group">
                                            <label for="tagline">Tagline</label>
                                            <input type="text" class="form-control" id="tagline" name="tagline" value="<?php echo e($info['tagline']); ?>" required>
                                        </div>
                                        <div class="form-group">
                                            <label for="deskripsiSingkat">Deskripsi Singkat</label>
                                            <textarea type="text" class="form-control" id="deskripsiSingkat" name="deskripsi" rows="3" required>
                                            <?php echo e($info['deskripsi-singkat']); ?>

                                        </textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="row">
                                    <div class="col-lg-8"></div>
                                    <div class="col-lg-2 mt-2 mt-sm-0">
                                        <button type="button" class="btn btn-block btn-outline-danger" id="btnCancel">Cancel</button>
                                    </div>
                                    <div class="col-lg-2 mt-2 mt-sm-0">
                                        <button type="submit" class="btn btn-block btn-success" id="btnEditData">Simpan</button>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>

                </div>
            </div>
            <!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        const iTagline = document.getElementById('tagline');
        const iDeskripsi = document.getElementById('deskripsiSingkat');

        const btnSimpan = document.getElementById('btnEditData');
        const btnCancel = document.getElementById('btnCancel');

        const formData = document.getElementById('formData');

        $(document).ready(function () {
            /*
            Button Action
             */
            formData.addEventListener('submit',function (e) {
                e.preventDefault();
                $.ajax({
                    url: '<?php echo e(url('admin/web-component/header-image/edit-data/submit')); ?>',
                    method: 'post',
                    data: $(this).serialize(),
                    success: function (response) {
                        console.log(response);
                        if (response === 'success') {
                            Swal.fire({
                                title: 'Data Tersimpan',
                                type: 'success',
                                onClose: function () {
                                    window.location.href = '<?php echo e(url('admin/web-component/header-image')); ?>';
                                }
                            });
                        } else {
                            Swal.fire({
                                title: 'Gagal Tersimpan',
                                text: 'Silahkan coba lagi',
                                type: 'error',
                            });
                        }
                    }
                })
            })
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kevin/Development/RayWhite/resources/views/dashboard/web-component/header-section_edit-data.blade.php ENDPATH**/ ?>