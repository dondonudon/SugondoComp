<section class="ftco-section ftco-no-pt">
    <div class="container">
        <div class="row justify-content-center mb-5">
            <div class="col-md-7 heading-section text-center ftco-animate">
                <span class="subheading">Blog</span>
                <h2>Our Activity</h2>
            </div>
        </div>
        <div class="row d-flex justify-content-md-center">
            <?php $__currentLoopData = $info['aktivitas-kita']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-3 d-flex ftco-animate">
                <div class="blog-entry justify-content-end">
                    <div class="text">
                        <h3 class="heading"><a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->judul); ?></a></h3>
                        <div class="meta mb-3">
                            <div><a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->created_at); ?></a></div>
                            <div><a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->username); ?></a></div>
                        </div>
                        <a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>" class="block-20 img" style="background-image: url('<?php echo e(url('storage/'.$a->image)); ?>');">
                        </a>
                        <p><?php echo e($a->short_desc); ?></p>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/aktivitas-kita.blade.php ENDPATH**/ ?>