<?php $__env->startSection('content'); ?>
    <section class="hero-wrap hero-wrap-2 ftco-degree-bg js-fullheight" style="background-color: lightgray;');" data-stellar-background-ratio="0.5">
        <div class="overlay" style="background-color: lightgray; opacity: 0.5;"></div>
        <div class="container">
            <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-center">
                <div class="col-md-9 ftco-animate pb-5 text-center">
                    
                    
                    <h1 class="mb-3 bread">Our Activity</h1>
                </div>
            </div>
        </div>
    </section>
    <section class="ftco-section ftco-no-pt">
        <div class="container mt-5">
            <div class="row d-flex justify-content-md-center">
                <?php $__currentLoopData = $aktivitas_kita; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3 d-flex ftco-animate">
                        <div class="blog-entry justify-content-end">
                            <div class="text">
                                <h3 class="heading"><a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->judul); ?></a></h3>
                                <div class="meta mb-3">
                                    <div>
                                        <a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->created_at); ?></a>
                                    </div>
                                    <div>
                                        <a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>"><?php echo e($a->username); ?></a>
                                    </div>
                                </div>
                                <a href="<?php echo e(url('aktivitas-kita/'.$a->id)); ?>" class="block-20 img" style="background-image: url('<?php echo e(url('storage/'.$a->image)); ?>');">
                                </a>
                                <p><?php echo e($a->short_desc); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('home.blog.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/blog/show-all.blade.php ENDPATH**/ ?>