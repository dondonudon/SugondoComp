
















<div class="hero-wrap ftco-degree-bg" style="background-image: url('<?php echo e(url('storage/'.$info['header-section-image']->filename)); ?>');" data-stellar-background-ratio="0.5" id="sectionHeader">
    <div class="overlay" style="background-color: lightgray; opacity: 0.5;"></div>
    <div class="container">
        <div class="row no-gutters slider-text justify-content-center align-items-center">
            <div class="col-lg-8 col-md-6 ftco-animate d-flex align-items-end">
                <div class="text text-center">
                    <h1 class="mb-4"><?php echo e($info['header-section']['tagline']); ?></h1>
                    <p style="font-size: 18px;"><?php echo e($info['header-section']['deskripsi-singkat']); ?></p>












                </div>
            </div>
        </div>
    </div>
    <div class="mouse">
        <a href="#" class="mouse-icon">
            <div class="mouse-wheel"><span class="ion-ios-arrow-round-down"></span></div>
        </a>
    </div>
</div>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/hero-section.blade.php ENDPATH**/ ?>