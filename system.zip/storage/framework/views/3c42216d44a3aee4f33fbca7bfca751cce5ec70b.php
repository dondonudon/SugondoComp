<footer class="main-footer">
    <!-- To the right -->



    <!-- Default to the left -->
    <strong><i class="far fa-copyright"></i> <?php echo e(date('Y')); ?> <a href="<?php echo e(config('app.client_web')); ?>"><?php echo e(config('app.app_client_name')); ?></a></strong>
</footer>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/dashboard/_partials/footer.blade.php ENDPATH**/ ?>