<section class="ftco-section goto-here" id="sectionQuote">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12 heading-section text-center ftco-animate mb-5">
                <span class="subheading">Quote of The Day</span>
                <h2 class="mb-2"><?php echo $info['quote-of-the-day']['data'] ?></h2>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/quote-of-the-day.blade.php ENDPATH**/ ?>