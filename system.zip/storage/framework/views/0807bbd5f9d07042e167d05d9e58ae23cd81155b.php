<section class="ftco-section ftco-agent goto-here mt-5" id="sectionSlider">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading">PROMO</span>
                <h2 class="mb-4">Ray White Promo</h2>
            </div>
        </div>
        <div class="row justify-content-md-center">
            <div class="col-md">
                <div id="slider_section">
                    <?php $__currentLoopData = $info['image-slider']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><img src="<?php echo e(url('storage/'.$i->filename)); ?>"></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/slider.blade.php ENDPATH**/ ?>