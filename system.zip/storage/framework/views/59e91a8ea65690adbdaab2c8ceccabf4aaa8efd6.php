<section class="ftco-section ftco-agent goto-here" id="sectionTopLister">
    <div class="container">
        <div class="row justify-content-center pb-5">
            <div class="col-md-12 heading-section text-center ftco-animate">
                <span class="subheading">LISTER</span>
                <h2 class="mb-4">Top Lister</h2>
            </div>
        </div>
        <div class="row justify-content-md-center">
            <?php $__currentLoopData = $info['top-lister']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3 ftco-animate">
                    <div class="agent">
                        <div class="img">
                            <img src="<?php echo e(url('storage/'.$t->photo)); ?>" class="img-fluid" alt="<?php echo e($t->fullname); ?>" style="width: auto; height: 250px;">
                        </div>
                        <div class="desc" style="background-color: yellow;">
                            <h3><?php echo e($t->fullname); ?></h3>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/landing-page/top-lister.blade.php ENDPATH**/ ?>