<?php
$segments = request()->segments();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <?php echo $__env->make('dashboard._partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Navbar -->
    <?php echo $__env->make('dashboard._partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /.navbar -->

    <!-- Main Sidebar Container -->
    <aside class="main-sidebar sidebar-dark-warning elevation-4">
        <?php echo $__env->make('dashboard._partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </aside>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <!-- Content Header (Page header) -->
        <div class="content-header">
            <?php if(\Illuminate\Support\Facades\Session::exists('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    Halaman yang anda inginkan tidak tersedia untuk anda, silahkan menghubungi administrator!
                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
            <?php endif; ?>
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0 text-dark"><?php echo $__env->yieldContent('page title'); ?></h1>
                    </div><!-- /.col -->
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-sm-right">
                            <?php if(count($segments) > 1): ?>
                                <li class="breadcrumb-item"><a href="<?php echo e(url('/')); ?>">home</a></li>
                                <li class="breadcrumb-item"><?php echo e($segments[0]); ?></li>
                                <li class="breadcrumb-item active"><?php echo e($segments[1]); ?></li>
                            <?php endif; ?>
                        </ol>
                    </div><!-- /.col -->
                </div><!-- /.row -->
            </div><!-- /.container-fluid -->
        </div>
        <!-- /.content-header -->

        <!-- Main content -->
        <?php echo $__env->yieldContent('content'); ?>
        <!-- /.content -->
    </div>
    <!-- /.content-wrapper -->

    <!-- Control Sidebar -->
    <aside class="control-sidebar control-sidebar-dark">
        <div class="row">
            <div class="col-lg m-2">
                <a class="btn btn-block btn-danger" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-power-off"></i>
                    Logout
                </a>
            </div>
        </div>
        <hr>
    </aside>
    <!-- /.control-sidebar -->

    <!-- Main Footer -->
    <?php echo $__env->make('dashboard._partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<!-- ./wrapper -->


<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Apakah anda ingin keluar?</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Silahkan klik tombol logout dibawah untuk mengakhiri sesi ini.</div>
            <div class="modal-footer">
                <button class="btn btn-outline-dark" type="button" data-dismiss="modal">Cancel</button>
                <button class="btn btn-danger" type="button" id="btnLogout">Logout</button>
            </div>
        </div>
    </div>
</div>


<!-- REQUIRED SCRIPTS -->
<?php echo $__env->make('dashboard._partials.footer-script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script>
    const btnLogout = $('#btnLogout');
    btnLogout.click(function (e) {
        e.preventDefault();
        $.ajax({
            url: "<?php echo e(url('overview/session-flush')); ?>",
            method: "get",
            success: function(result) {
                // console.log(result);
                if (result === 'success') {
                    document.location.reload();
                } else {
                    Swal.fire({
                        type: 'info',
                        title: 'Gagal Logout',
                    });
                }
            }
        });
    })
</script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/dashboard/layout.blade.php ENDPATH**/ ?>