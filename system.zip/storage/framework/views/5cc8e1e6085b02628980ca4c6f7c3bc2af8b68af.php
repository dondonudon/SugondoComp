<nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <span class="navbar-brand" href="<?php echo e(url('/')); ?>" style="position: absolute; top: -10px" onclick="goToSection('sectionHeader')">
            <img class="img-fluid" src="<?php echo e(asset('home/images/rw-logo-2017.jpg')); ?>" alt="logo" width="65%">
        </span>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionSlider')">
                    <span class="nav-link">Promo</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionAboutUs')">
                    <span class="nav-link">About Us</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionQuote')">
                    <span class="nav-link">Quote</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionTopLister')">
                    <span class="nav-link">Top Lister</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionTopMarketer')">
                    <span class="nav-link">Top Marketer</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionFavoriteMarketer')">
                    <span class="nav-link">Favorite Marketer</span>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionOurTeam')">
                    <span class="nav-link">Our Team</span>
                </li>
                <li class="nav-item" style="background-color: yellow">
                    <a href="<?php echo e(url('aktivitas-kita')); ?>" class="nav-link">Our Activity</a>
                </li>
                <li class="nav-item" style="background-color: yellow" onclick="goToSection('sectionForSale')">
                    <span class="nav-link">For Sale</span>
                </li>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/kevin/Development/RayWhite/resources/views/home/_partials/navbar.blade.php ENDPATH**/ ?>